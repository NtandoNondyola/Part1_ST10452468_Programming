package part1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Dylan
 */
public class LoginServiceIT {
    
    private LoginService loginService;
    
    public LoginServiceIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        loginService = new LoginService();
    }
    
    @After
    public void tearDown() {
        loginService = null;
    }

    /**
     * Test of checkUserName method, of class LoginService.
     */
    @Test
    public void testCheckUserNameValid() {
        System.out.println("checkUserName - Valid");
        String username = "My_";
        boolean result = loginService.checkUserName(username);
        assertTrue("Username should be valid (contains underscore and <=5 chars)", result);
    }
    
    @Test
    public void testCheckUserNameInvalid() {
        System.out.println("checkUserName - Invalid");
        String username = "hyhell!!!!!";
        boolean result = loginService.checkUserName(username);
        assertFalse("Username should be invalid (no underscore or >5 chars)", result);
    }

    /**
     * Test of checkPasswordComplexity method, of class LoginService.
     */
    @Test
    public void testCheckPasswordComplexityValid() {
        System.out.println("checkPasswordComplexity - Valid");
        String password = "Ch&5sec@le29t";
        boolean result = loginService.checkPasswordComplexity(password);
        assertTrue("Password should meet complexity requirements", result);
    }
    
    @Test
    public void testCheckPasswordComplexityInvalid() {
        System.out.println("checkPasswordComplexity - Invalid");
        String password = "password";
        boolean result = loginService.checkPasswordComplexity(password);
        assertFalse("Password should not meet complexity requirements", result);
    }

    /**
     * Test of checkCellPhoneNumber method, of class LoginService.
     */
    @Test
    public void testCheckCellPhoneNumberValid() {
        System.out.println("checkCellPhoneNumber - Valid");
        String phone = "+27123456789";
        boolean result = loginService.checkCellPhoneNumber(phone);
        assertTrue("Phone number should be valid", result);
    }
    
    @Test
    public void testCheckCellPhoneNumberInvalid() {
        System.out.println("checkCellPhoneNumber - Invalid");
        String phone = "03986533";
        boolean result = loginService.checkCellPhoneNumber(phone);
        assertFalse("Phone number should be invalid", result);
    }

    /**
     * Test of registerUser method, of class LoginService.
     */
    @Test
    public void testRegisterUserSuccess() {
        System.out.println("registerUser - Success");
        String firstName = "John";
        String lastName = "Doe";
        String username = "My_";
        String password = "Ch&5sec@le29t";
        String phone = "+27123456789";
        
        String result = loginService.registerUser(firstName, lastName, username, password, phone);
        assertNull("Registration should be successful (return null)", result);
    }
    
    @Test
    public void testRegisterUserInvalidUsername() {
        System.out.println("registerUser - Invalid Username");
        String firstName = "John";
        String lastName = "Doe";
        String username = "hyhell!!!!!";
        String password = "Ch&5sec@le29t";
        String phone = "+27123456789";
        
        String result = loginService.registerUser(firstName, lastName, username, password, phone);
        assertEquals("Should return username error message", 
                     "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.", 
                     result);
    }
    
    @Test
    public void testRegisterUserInvalidPassword() {
        System.out.println("registerUser - Invalid Password");
        String firstName = "John";
        String lastName = "Doe";
        String username = "My_";
        String password = "password";
        String phone = "+27123456789";
        
        String result = loginService.registerUser(firstName, lastName, username, password, phone);
        assertEquals("Should return password error message", 
                     "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.", 
                     result);
    }

    /**
     * Test of loginUser method, of class LoginService.
     */
    @Test
    public void testLoginUserSuccess() {
        System.out.println("loginUser - Success");
        // First register a user
        loginService.registerUser("John", "Doe", "My_", "Ch&5sec@le29t", "+27123456789");
        
        // Then try to login
        boolean result = loginService.loginUser("My_", "Ch&5sec@le29t");
        assertTrue("Login should be successful", result);
    }
    
    @Test
    public void testLoginUserFailure() {
        System.out.println("loginUser - Failure");
        // First register a user
        loginService.registerUser("John", "Doe", "My_", "Ch&5sec@le29t", "+27123456789");
        
        // Then try to login with wrong password
        boolean result = loginService.loginUser("My_", "wrongpassword");
        assertFalse("Login should fail with wrong password", result);
    }

    /**
     * Test of returnLoginStatus method, of class LoginService.
     */
    @Test
    public void testReturnLoginStatusSuccess() {
        System.out.println("returnLoginStatus - Success");
        // First register a user
        loginService.registerUser("John", "Doe", "My_", "Ch&5sec@le29t", "+27123456789");
        
        // Then get login status
        String result = loginService.returnLoginStatus("My_", "Ch&5sec@le29t");
        assertEquals("Should return welcome message", 
                     "Welcome John, Doe it is great to see you.", 
                     result);
    }
    
    @Test
    public void testReturnLoginStatusFailure() {
        System.out.println("returnLoginStatus - Failure");
        // First register a user
        loginService.registerUser("John", "Doe", "My_", "Ch&5sec@le29t", "+27123456789");
        
        // Then get login status with wrong password
        String result = loginService.returnLoginStatus("My_", "wrongpassword");
        assertEquals("Should return failed login message", 
                     "Failed login. Please check your username and password.", 
                     result);
    }
}