package part1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RegisterForm extends JFrame {
    private final JTextField firstNameField;
    private final JTextField lastNameField;
    private final JTextField userTextField;
    private final JPasswordField passwordField;
    private final JPasswordField confirmPasswordField;
    private final JTextField phoneField;
    private final JButton registerButton;
    private final JLabel messageLabel;
    private final LoginService loginService;

    public RegisterForm(LoginService loginService) {
        this.loginService = loginService;
        
        setTitle("Register Form");
        setSize(500, 380);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        // First Name
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setBounds(50, 30, 120, 25);
        firstNameLabel.setForeground(new Color(0, 102, 204));
        add(firstNameLabel);

        firstNameField = new JTextField();
        firstNameField.setBounds(180, 30, 250, 25);
        firstNameField.setBackground(new Color(224, 235, 255));
        add(firstNameField);

        // Last Name
        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setBounds(50, 70, 120, 25);
        lastNameLabel.setForeground(new Color(0, 102, 204));
        add(lastNameLabel);

        lastNameField = new JTextField();
        lastNameField.setBounds(180, 70, 250, 25);
        lastNameField.setBackground(new Color(224, 235, 255));
        add(lastNameField);

        // Username
        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(50, 110, 120, 25);
        userLabel.setForeground(new Color(0, 102, 204));
        add(userLabel);

        userTextField = new JTextField();
        userTextField.setBounds(180, 110, 250, 25);
        userTextField.setBackground(new Color(224, 235, 255));
        add(userTextField);

        // Password
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 150, 120, 25);
        passwordLabel.setForeground(new Color(0, 102, 204));
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(180, 150, 250, 25);
        passwordField.setBackground(new Color(224, 235, 255));
        add(passwordField);

        // Confirm Password
        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        confirmPasswordLabel.setBounds(50, 190, 120, 25);
        confirmPasswordLabel.setForeground(new Color(0, 102, 204));
        add(confirmPasswordLabel);

        confirmPasswordField = new JPasswordField();
        confirmPasswordField.setBounds(180, 190, 250, 25);
        confirmPasswordField.setBackground(new Color(224, 235, 255));
        add(confirmPasswordField);

        // Phone Number
        JLabel phoneLabel = new JLabel("Phone Number:");
        phoneLabel.setBounds(50, 230, 120, 25);
        phoneLabel.setForeground(new Color(0, 102, 204));
        add(phoneLabel);

        phoneField = new JTextField();
        phoneField.setBounds(180, 230, 250, 25);
        phoneField.setBackground(new Color(224, 235, 255));
        phoneField.setToolTipText("Format: +27XXXXXXXXX");
        add(phoneField);

        // Register Button
        registerButton = new JButton("Register");
        registerButton.setBounds(180, 280, 120, 35);
        registerButton.setBackground(new Color(0, 102, 204));
        registerButton.setForeground(Color.WHITE);
        registerButton.setFocusPainted(false);
        add(registerButton);

        // Message Label
        messageLabel = new JLabel("");
        messageLabel.setBounds(50, 320, 400, 25);
        messageLabel.setForeground(Color.RED);
        add(messageLabel);

        // Register button action
        registerButton.addActionListener((ActionEvent e) -> registerAction());
    }

   private void registerAction() {
    String firstName = firstNameField.getText().trim();
    String lastName = lastNameField.getText().trim();
    String username = userTextField.getText().trim();
    String password = new String(passwordField.getPassword());
    String confirmPassword = new String(confirmPasswordField.getPassword());
    String phone = phoneField.getText().trim();

    if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || phone.isEmpty()) {
        setMessage("Please fill in all fields.", Color.RED);
        return;
    }

    if (!password.equals(confirmPassword)) {
        setMessage("Passwords do not match.", Color.RED);
        return;
    }

    if (!loginService.checkCellPhoneNumber(phone)) {
        setMessage("Phone number must start with +27 followed by 9 digits.", Color.RED);
        return;
    }

    String result = loginService.registerUser(firstName, lastName, username, password, phone);
    if (result == null) {
        setMessage("Registration successful!", new Color(0, 153, 0));
        clearFields();
    } else {
        setMessage(result, Color.RED);
    }
}

    private void setMessage(String message, Color color) {
        messageLabel.setText(message);
        messageLabel.setForeground(color);
    }

    private void clearFields() {
        firstNameField.setText("");
        lastNameField.setText("");
        userTextField.setText("");
        passwordField.setText("");
        confirmPasswordField.setText("");
        phoneField.setText("");
    }
}