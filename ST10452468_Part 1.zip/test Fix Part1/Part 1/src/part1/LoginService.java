package part1;

import java.util.HashMap;
import java.util.Map;

public class LoginService {

    private class User {
        String firstName;
        String lastName;
        String username;
        String password;
        String phone;

        public User(String firstName, String lastName, String username, String password, String phone) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.username = username;
            this.password = password;
            this.phone = phone;
        }

        public String getFirstName() { return firstName; }
        public String getLastName() { return lastName; }
        public String getPassword() { return password; }
    }

    private Map<String, User> registeredUsers = new HashMap<>();

    public boolean checkUserName(String username) {
        return username.length() <= 5 && username.contains("_");
    }

    public boolean checkPasswordComplexity(String password) {
        if (password.length() < 8) return false;
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasCapital = true;
            if (Character.isDigit(c)) hasNumber = true;
            if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        return hasCapital && hasNumber && hasSpecial;
    }

    public boolean checkCellPhoneNumber(String phone) {
        return phone.matches("^\\+27[0-9]{9}$");
    }

    public String registerUser(String firstName, String lastName, String username, String password, String phone) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (registeredUsers.containsKey(username)) {
            return "Username already exists.";
        }
        User newUser = new User(firstName, lastName, username, password, phone);
        registeredUsers.put(username, newUser);
        return null;
    }

    public boolean loginUser(String username, String password) {
        if (!registeredUsers.containsKey(username)) {
            return false;
        }
        User user = registeredUsers.get(username);
        return user.getPassword().equals(password);
    }

    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) {
            User user = registeredUsers.get(username);
            return "Welcome " + user.getFirstName() + ", " + user.getLastName() + " it is great to see you.";
        } else {
            return "Failed login. Please check your username and password.";
        }
    }
}